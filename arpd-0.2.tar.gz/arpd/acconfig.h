/* Define if the addr_cmp in libdnet is broken */
#undef HAVE_BROKEN_DNET

